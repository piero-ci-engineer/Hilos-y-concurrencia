package poocuadrados;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;

public class Dibujo extends Thread {

    private JLabel eti;
    private Principal p;

    public Dibujo(JLabel eti, Principal p) {
        this.eti = eti;
        this.p = p;
    }

    @Override
    public void run() {
        int c1 = 0, c2 = 0, c3 = 0;
        while (true) {
            try {
                sleep((int) (Math.random() * 1000));
            } catch (InterruptedException ex) {
                Logger.getLogger(Dibujo.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            break;
        }

    }
}