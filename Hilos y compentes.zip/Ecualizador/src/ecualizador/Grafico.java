package ecualizador;

import java.awt.Color;

public class Grafico extends javax.swing.JFrame {

    public Grafico() {
        initComponents();
        iniciar();
    }

    public void iniciar() {
        this.setTitle("Ecualizador");
        setLocationRelativeTo(null);
        
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);

        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        f1.setBackground(Color.black);
        f2.setBackground(Color.black);
        f3.setBackground(Color.black);
        f4.setBackground(Color.black);
        f5.setBackground(Color.black);
        f6.setBackground(Color.black);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        b1 = new javax.swing.JButton();
        c2 = new javax.swing.JButton();
        d1 = new javax.swing.JButton();
        e1 = new javax.swing.JButton();
        f1 = new javax.swing.JButton();
        a1 = new javax.swing.JButton();
        d2 = new javax.swing.JButton();
        e2 = new javax.swing.JButton();
        f2 = new javax.swing.JButton();
        a3 = new javax.swing.JButton();
        c3 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        d3 = new javax.swing.JButton();
        e3 = new javax.swing.JButton();
        f3 = new javax.swing.JButton();
        f4 = new javax.swing.JButton();
        d4 = new javax.swing.JButton();
        c4 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        a4 = new javax.swing.JButton();
        a5 = new javax.swing.JButton();
        b5 = new javax.swing.JButton();
        c5 = new javax.swing.JButton();
        e5 = new javax.swing.JButton();
        f5 = new javax.swing.JButton();
        d5 = new javax.swing.JButton();
        a6 = new javax.swing.JButton();
        b6 = new javax.swing.JButton();
        c6 = new javax.swing.JButton();
        f6 = new javax.swing.JButton();
        d6 = new javax.swing.JButton();
        e6 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        a2 = new javax.swing.JButton();
        c1 = new javax.swing.JButton();
        e4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        b1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b1MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b1MouseEntered(evt);
            }
        });

        c2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                c2MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                c2MouseEntered(evt);
            }
        });

        d1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                d1MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                d1MouseEntered(evt);
            }
        });

        e1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                e1MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                e1MouseEntered(evt);
            }
        });

        f1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                f1MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                f1MouseEntered(evt);
            }
        });

        a1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                a1MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                a1MouseEntered(evt);
            }
        });

        d2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                d2MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                d2MouseEntered(evt);
            }
        });

        e2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                e2MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                e2MouseEntered(evt);
            }
        });

        f2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                f2MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                f2MouseEntered(evt);
            }
        });

        a3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                a3MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                a3MouseEntered(evt);
            }
        });

        c3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                c3MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                c3MouseEntered(evt);
            }
        });

        b3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b3MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b3MouseEntered(evt);
            }
        });

        d3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                d3MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                d3MouseEntered(evt);
            }
        });

        e3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                e3MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                e3MouseEntered(evt);
            }
        });

        f3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                f3MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                f3MouseEntered(evt);
            }
        });

        f4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                f4MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                f4MouseEntered(evt);
            }
        });

        d4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                d4MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                d4MouseEntered(evt);
            }
        });

        c4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                c4MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                c4MouseEntered(evt);
            }
        });

        b4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b4MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b4MouseEntered(evt);
            }
        });

        a4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                a4MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                a4MouseEntered(evt);
            }
        });

        a5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                a5MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                a5MouseEntered(evt);
            }
        });

        b5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b5MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b5MouseEntered(evt);
            }
        });

        c5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                c5MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                c5MouseEntered(evt);
            }
        });

        e5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                e5MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                e5MouseEntered(evt);
            }
        });

        f5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                f5MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                f5MouseEntered(evt);
            }
        });

        d5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                d5MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                d5MouseEntered(evt);
            }
        });

        a6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                a6MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                a6MouseEntered(evt);
            }
        });

        b6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b6MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b6MouseEntered(evt);
            }
        });

        c6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                c6MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                c6MouseEntered(evt);
            }
        });

        f6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                f6MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                f6MouseEntered(evt);
            }
        });

        d6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                d6MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                d6MouseEntered(evt);
            }
        });

        e6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                e6MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                e6MouseEntered(evt);
            }
        });

        b2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b2MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b2MouseEntered(evt);
            }
        });

        a2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                a2MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                a2MouseEntered(evt);
            }
        });

        c1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                c1MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                c1MouseEntered(evt);
            }
        });

        e4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                e4MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                e4MouseEntered(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(a6, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(c6, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(d6, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(a5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(b5, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(a3, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)
                                        .addComponent(a4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(a2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGap(18, 18, 18)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(a1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(c3, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)
                            .addComponent(c4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(c5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(c2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(c1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(d4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(d3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(d5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(d1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(d2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(e6, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(f6, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(e1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)
                            .addComponent(e5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(e2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(e3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(e4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(f4, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(f2, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(f3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(f5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(f1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(a6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(d6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(e6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(f6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(e5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(f5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(d5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(a5, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(f4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(d4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(c4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(a4, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                    .addComponent(b4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(e4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(a3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(c3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(d3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(e3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(f3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(d2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(f2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(e2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(b2, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
                        .addComponent(a2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(c2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(b1, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
                    .addComponent(a1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(d1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(e1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(f1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(c1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void d5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d5MouseEntered
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
        d2.setBackground(Color.cyan);
        d3.setBackground(Color.cyan);
        d4.setBackground(Color.cyan);
        d5.setBackground(Color.cyan);
    }//GEN-LAST:event_d5MouseEntered

    private void d5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d5MouseExited
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
        d2.setBackground(Color.cyan);
        d3.setBackground(Color.cyan);
        d4.setBackground(Color.cyan);
        d5.setBackground(Color.cyan);
    }//GEN-LAST:event_d5MouseExited

    private void f5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f5MouseEntered
        f1.setBackground(Color.black);
        f2.setBackground(Color.black);
        f3.setBackground(Color.black);
        f4.setBackground(Color.black);
        f5.setBackground(Color.black);
        f6.setBackground(Color.black);

        f1.setBackground(Color.BLUE);
        f2.setBackground(Color.BLUE);
        f3.setBackground(Color.BLUE);
        f4.setBackground(Color.BLUE);
        f5.setBackground(Color.BLUE);
    }//GEN-LAST:event_f5MouseEntered

    private void f5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f5MouseExited
        f1.setBackground(Color.black);
        f2.setBackground(Color.black);
        f3.setBackground(Color.black);
        f4.setBackground(Color.black);
        f5.setBackground(Color.black);
        f6.setBackground(Color.black);

        f1.setBackground(Color.BLUE);
        f2.setBackground(Color.BLUE);
        f3.setBackground(Color.BLUE);
        f4.setBackground(Color.BLUE);
        f5.setBackground(Color.BLUE);
    }//GEN-LAST:event_f5MouseExited

    private void e5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e5MouseEntered
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
        e2.setBackground(Color.MAGENTA);
        e3.setBackground(Color.MAGENTA);
        e4.setBackground(Color.MAGENTA);
        e5.setBackground(Color.MAGENTA);
    }//GEN-LAST:event_e5MouseEntered

    private void e5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e5MouseExited
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
        e2.setBackground(Color.MAGENTA);
        e3.setBackground(Color.MAGENTA);
        e4.setBackground(Color.MAGENTA);
        e5.setBackground(Color.MAGENTA);
    }//GEN-LAST:event_e5MouseExited

    private void c1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c1MouseEntered
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
    }//GEN-LAST:event_c1MouseEntered

    private void c1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c1MouseExited
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
    }//GEN-LAST:event_c1MouseExited

    private void a1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a1MouseEntered
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);

        a1.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a1MouseEntered

    private void a1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a1MouseExited
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);

        a1.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a1MouseExited

    private void f1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f1MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_f1MouseEntered

    private void f1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_f1MouseExited

    private void e1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e1MouseEntered
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
    }//GEN-LAST:event_e1MouseEntered

    private void e1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e1MouseExited
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
    }//GEN-LAST:event_e1MouseExited

    private void d1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d1MouseEntered
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
    }//GEN-LAST:event_d1MouseEntered

    private void d1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d1MouseExited
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
    }//GEN-LAST:event_d1MouseExited

    private void c2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c2MouseEntered
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
        c2.setBackground(Color.PINK);
    }//GEN-LAST:event_c2MouseEntered

    private void c2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c2MouseExited
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
        c2.setBackground(Color.PINK);
    }//GEN-LAST:event_c2MouseExited

    private void b1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b1MouseEntered
        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
    }//GEN-LAST:event_b1MouseEntered

    private void b1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b1MouseExited
        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
    }//GEN-LAST:event_b1MouseExited

    private void c3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c3MouseEntered
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
        c2.setBackground(Color.PINK);
        c3.setBackground(Color.PINK);
    }//GEN-LAST:event_c3MouseEntered

    private void c3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c3MouseExited
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
        c2.setBackground(Color.PINK);
        c3.setBackground(Color.PINK);
    }//GEN-LAST:event_c3MouseExited

    private void a3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a3MouseEntered
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);

        a1.setBackground(Color.YELLOW);
        a2.setBackground(Color.YELLOW);
        a3.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a3MouseEntered

    private void a3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a3MouseExited
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);

        a1.setBackground(Color.YELLOW);
        a2.setBackground(Color.YELLOW);
        a3.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a3MouseExited

    private void c5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c5MouseEntered
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
        c2.setBackground(Color.PINK);
        c3.setBackground(Color.PINK);
        c4.setBackground(Color.PINK);
        c5.setBackground(Color.PINK);
    }//GEN-LAST:event_c5MouseEntered

    private void c5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c5MouseExited
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
        c2.setBackground(Color.PINK);
        c3.setBackground(Color.PINK);
        c4.setBackground(Color.PINK);
        c5.setBackground(Color.PINK);
    }//GEN-LAST:event_c5MouseExited

    private void f2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f2MouseEntered
        f1.setBackground(Color.black);
        f2.setBackground(Color.black);
        f3.setBackground(Color.black);
        f4.setBackground(Color.black);
        f5.setBackground(Color.black);
        f6.setBackground(Color.black);

        f1.setBackground(Color.BLUE);
        f2.setBackground(Color.BLUE);
    }//GEN-LAST:event_f2MouseEntered

    private void f2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f2MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_f2MouseExited

    private void a2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a2MouseEntered
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);

        a1.setBackground(Color.YELLOW);
        a2.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a2MouseEntered

    private void a2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a2MouseExited
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);

        a1.setBackground(Color.YELLOW);
        a2.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a2MouseExited

    private void b5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b5MouseEntered
        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
        b2.setBackground(Color.GREEN);
        b3.setBackground(Color.GREEN);
        b4.setBackground(Color.GREEN);
        b5.setBackground(Color.GREEN);
    }//GEN-LAST:event_b5MouseEntered

    private void b5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b5MouseExited
        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
        b2.setBackground(Color.GREEN);
        b3.setBackground(Color.GREEN);
        b4.setBackground(Color.GREEN);
        b5.setBackground(Color.GREEN);
    }//GEN-LAST:event_b5MouseExited

    private void e2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e2MouseEntered
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
        e2.setBackground(Color.MAGENTA);
    }//GEN-LAST:event_e2MouseEntered

    private void e2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e2MouseExited
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
        e2.setBackground(Color.MAGENTA);
    }//GEN-LAST:event_e2MouseExited

    private void d2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d2MouseEntered
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
        d2.setBackground(Color.cyan);
    }//GEN-LAST:event_d2MouseEntered

    private void d2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d2MouseExited
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
        d2.setBackground(Color.cyan);
    }//GEN-LAST:event_d2MouseExited

    private void b2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b2MouseEntered
        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
        b2.setBackground(Color.GREEN);
    }//GEN-LAST:event_b2MouseEntered

    private void b2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b2MouseExited
        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
        b2.setBackground(Color.GREEN);
    }//GEN-LAST:event_b2MouseExited

    private void a5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a5MouseEntered
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);

        a1.setBackground(Color.YELLOW);
        a2.setBackground(Color.YELLOW);
        a3.setBackground(Color.YELLOW);
        a4.setBackground(Color.YELLOW);
        a5.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a5MouseEntered

    private void a5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a5MouseExited
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);

        a1.setBackground(Color.YELLOW);
        a2.setBackground(Color.YELLOW);
        a3.setBackground(Color.YELLOW);
        a4.setBackground(Color.YELLOW);
        a5.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a5MouseExited

    private void a4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a4MouseEntered
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);

        a1.setBackground(Color.YELLOW);
        a2.setBackground(Color.YELLOW);
        a3.setBackground(Color.YELLOW);
        a4.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a4MouseEntered

    private void a4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a4MouseExited
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);

        a1.setBackground(Color.YELLOW);
        a2.setBackground(Color.YELLOW);
        a3.setBackground(Color.YELLOW);
        a4.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a4MouseExited

    private void b4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b4MouseEntered
        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
        b2.setBackground(Color.GREEN);
        b3.setBackground(Color.GREEN);
        b4.setBackground(Color.GREEN);
    }//GEN-LAST:event_b4MouseEntered

    private void b4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b4MouseExited
        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
        b2.setBackground(Color.GREEN);
        b3.setBackground(Color.GREEN);
        b4.setBackground(Color.GREEN);
    }//GEN-LAST:event_b4MouseExited

    private void c4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c4MouseEntered
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
        c2.setBackground(Color.PINK);
        c3.setBackground(Color.PINK);
        c4.setBackground(Color.PINK);
    }//GEN-LAST:event_c4MouseEntered

    private void c4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c4MouseExited
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
        c2.setBackground(Color.PINK);
        c3.setBackground(Color.PINK);
        c4.setBackground(Color.PINK);
    }//GEN-LAST:event_c4MouseExited

    private void d4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d4MouseEntered
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
        d2.setBackground(Color.cyan);
        d3.setBackground(Color.cyan);
        d4.setBackground(Color.cyan);
    }//GEN-LAST:event_d4MouseEntered

    private void d4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d4MouseExited
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
        d2.setBackground(Color.cyan);
        d3.setBackground(Color.cyan);
        d4.setBackground(Color.cyan);
    }//GEN-LAST:event_d4MouseExited

    private void e6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e6MouseEntered
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
        e2.setBackground(Color.MAGENTA);
        e3.setBackground(Color.MAGENTA);
        e4.setBackground(Color.MAGENTA);
        e5.setBackground(Color.MAGENTA);
        e6.setBackground(Color.MAGENTA);
    }//GEN-LAST:event_e6MouseEntered

    private void e6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e6MouseExited
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
        e2.setBackground(Color.MAGENTA);
        e3.setBackground(Color.MAGENTA);
        e4.setBackground(Color.MAGENTA);
        e5.setBackground(Color.MAGENTA);
        e6.setBackground(Color.MAGENTA);
    }//GEN-LAST:event_e6MouseExited

    private void d6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d6MouseEntered
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
        d2.setBackground(Color.cyan);
        d3.setBackground(Color.cyan);
        d4.setBackground(Color.cyan);
        d5.setBackground(Color.cyan);
        d6.setBackground(Color.cyan);
    }//GEN-LAST:event_d6MouseEntered

    private void d6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d6MouseExited
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
        d2.setBackground(Color.cyan);
        d3.setBackground(Color.cyan);
        d4.setBackground(Color.cyan);
        d5.setBackground(Color.cyan);
        d6.setBackground(Color.cyan);
    }//GEN-LAST:event_d6MouseExited

    private void f4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f4MouseEntered
        f1.setBackground(Color.black);
        f2.setBackground(Color.black);
        f3.setBackground(Color.black);
        f4.setBackground(Color.black);
        f5.setBackground(Color.black);
        f6.setBackground(Color.black);

        f1.setBackground(Color.BLUE);
        f2.setBackground(Color.BLUE);
        f3.setBackground(Color.BLUE);
        f4.setBackground(Color.BLUE);
    }//GEN-LAST:event_f4MouseEntered

    private void f4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f4MouseExited
        f1.setBackground(Color.black);
        f2.setBackground(Color.black);
        f3.setBackground(Color.black);
        f4.setBackground(Color.black);
        f5.setBackground(Color.black);
        f6.setBackground(Color.black);

        f1.setBackground(Color.BLUE);
        f2.setBackground(Color.BLUE);
        f3.setBackground(Color.BLUE);
        f4.setBackground(Color.BLUE);
    }//GEN-LAST:event_f4MouseExited

    private void f6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f6MouseEntered
        f1.setBackground(Color.black);
        f2.setBackground(Color.black);
        f3.setBackground(Color.black);
        f4.setBackground(Color.black);
        f5.setBackground(Color.black);
        f6.setBackground(Color.black);

        f1.setBackground(Color.BLUE);
        f2.setBackground(Color.BLUE);
        f3.setBackground(Color.BLUE);
        f4.setBackground(Color.BLUE);
        f5.setBackground(Color.BLUE);
        f6.setBackground(Color.BLUE);
    }//GEN-LAST:event_f6MouseEntered

    private void f6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f6MouseExited
        f1.setBackground(Color.black);
        f2.setBackground(Color.black);
        f3.setBackground(Color.black);
        f4.setBackground(Color.black);
        f5.setBackground(Color.black);
        f6.setBackground(Color.black);

        f1.setBackground(Color.BLUE);
        f2.setBackground(Color.BLUE);
        f3.setBackground(Color.BLUE);
        f4.setBackground(Color.BLUE);
        f5.setBackground(Color.BLUE);
        f6.setBackground(Color.BLUE);
    }//GEN-LAST:event_f6MouseExited

    private void f3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f3MouseEntered
        f1.setBackground(Color.black);
        f2.setBackground(Color.black);
        f3.setBackground(Color.black);
        f4.setBackground(Color.black);
        f5.setBackground(Color.black);
        f6.setBackground(Color.black);

        f1.setBackground(Color.BLUE);
        f2.setBackground(Color.BLUE);
        f3.setBackground(Color.BLUE);
    }//GEN-LAST:event_f3MouseEntered

    private void f3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_f3MouseExited
        f1.setBackground(Color.black);
        f2.setBackground(Color.black);
        f3.setBackground(Color.black);
        f4.setBackground(Color.black);
        f5.setBackground(Color.black);
        f6.setBackground(Color.black);

        f1.setBackground(Color.BLUE);
        f2.setBackground(Color.BLUE);
        f3.setBackground(Color.BLUE);
    }//GEN-LAST:event_f3MouseExited

    private void c6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c6MouseEntered
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
        c2.setBackground(Color.PINK);
        c3.setBackground(Color.PINK);
        c4.setBackground(Color.PINK);
        c5.setBackground(Color.PINK);
        c6.setBackground(Color.PINK);
    }//GEN-LAST:event_c6MouseEntered

    private void c6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c6MouseExited
        c1.setBackground(Color.black);
        c2.setBackground(Color.black);
        c3.setBackground(Color.black);
        c4.setBackground(Color.black);
        c5.setBackground(Color.black);
        c6.setBackground(Color.black);

        c1.setBackground(Color.PINK);
        c2.setBackground(Color.PINK);
        c3.setBackground(Color.PINK);
        c4.setBackground(Color.PINK);
        c5.setBackground(Color.PINK);
        c6.setBackground(Color.PINK);
    }//GEN-LAST:event_c6MouseExited

    private void e3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e3MouseEntered
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
        e2.setBackground(Color.MAGENTA);
        e3.setBackground(Color.MAGENTA);
    }//GEN-LAST:event_e3MouseEntered

    private void e3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e3MouseExited
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
        e2.setBackground(Color.MAGENTA);
        e3.setBackground(Color.MAGENTA);
    }//GEN-LAST:event_e3MouseExited

    private void b6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b6MouseEntered

        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
        b2.setBackground(Color.GREEN);
        b3.setBackground(Color.GREEN);
        b4.setBackground(Color.GREEN);
        b5.setBackground(Color.GREEN);
        b6.setBackground(Color.GREEN);
    }//GEN-LAST:event_b6MouseEntered

    private void b6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b6MouseExited
        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
        b2.setBackground(Color.GREEN);
        b3.setBackground(Color.GREEN);
        b4.setBackground(Color.GREEN);
        b5.setBackground(Color.GREEN);
        b6.setBackground(Color.GREEN);
    }//GEN-LAST:event_b6MouseExited

    private void d3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d3MouseEntered
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
        d2.setBackground(Color.cyan);
        d3.setBackground(Color.cyan);
    }//GEN-LAST:event_d3MouseEntered

    private void d3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_d3MouseExited
        d1.setBackground(Color.black);
        d2.setBackground(Color.black);
        d3.setBackground(Color.black);
        d4.setBackground(Color.black);
        d5.setBackground(Color.black);
        d6.setBackground(Color.black);

        d1.setBackground(Color.cyan);
        d2.setBackground(Color.cyan);
        d3.setBackground(Color.cyan);
    }//GEN-LAST:event_d3MouseExited

    private void a6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a6MouseEntered
        a1.setBackground(Color.BLACK);
        a2.setBackground(Color.BLACK);
        a3.setBackground(Color.BLACK);
        a4.setBackground(Color.BLACK);
        a5.setBackground(Color.BLACK);
        a6.setBackground(Color.BLACK);

        a1.setBackground(Color.YELLOW);
        a2.setBackground(Color.YELLOW);
        a3.setBackground(Color.YELLOW);
        a4.setBackground(Color.YELLOW);
        a5.setBackground(Color.YELLOW);
        a6.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a6MouseEntered

    private void a6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a6MouseExited
        a1.setBackground(Color.BLACK);
        a2.setBackground(Color.BLACK);
        a3.setBackground(Color.BLACK);
        a4.setBackground(Color.BLACK);
        a5.setBackground(Color.BLACK);
        a6.setBackground(Color.BLACK);

        a1.setBackground(Color.YELLOW);
        a2.setBackground(Color.YELLOW);
        a3.setBackground(Color.YELLOW);
        a4.setBackground(Color.YELLOW);
        a5.setBackground(Color.YELLOW);
        a6.setBackground(Color.YELLOW);
    }//GEN-LAST:event_a6MouseExited

    private void b3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b3MouseEntered
        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
        b2.setBackground(Color.GREEN);
        b3.setBackground(Color.GREEN);
    }//GEN-LAST:event_b3MouseEntered

    private void b3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b3MouseExited
        b1.setBackground(Color.black);
        b2.setBackground(Color.black);
        b3.setBackground(Color.black);
        b4.setBackground(Color.black);
        b5.setBackground(Color.black);
        b6.setBackground(Color.black);

        b1.setBackground(Color.GREEN);
        b2.setBackground(Color.GREEN);
        b3.setBackground(Color.GREEN);
    }//GEN-LAST:event_b3MouseExited

    private void e4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e4MouseEntered
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
        e2.setBackground(Color.MAGENTA);
        e3.setBackground(Color.MAGENTA);
        e4.setBackground(Color.MAGENTA);
    }//GEN-LAST:event_e4MouseEntered

    private void e4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_e4MouseExited
        e1.setBackground(Color.black);
        e2.setBackground(Color.black);
        e3.setBackground(Color.black);
        e4.setBackground(Color.black);
        e5.setBackground(Color.black);
        e6.setBackground(Color.black);

        e1.setBackground(Color.MAGENTA);
        e2.setBackground(Color.MAGENTA);
        e3.setBackground(Color.MAGENTA);
        e4.setBackground(Color.MAGENTA);  
    }//GEN-LAST:event_e4MouseExited

    public void A1() {
        a1.setBackground(Color.black);
        a2.setBackground(Color.black);
        a3.setBackground(Color.black);
        a4.setBackground(Color.black);
        a5.setBackground(Color.black);
        a6.setBackground(Color.black);
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Grafico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Grafico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Grafico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Grafico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Grafico().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton a1;
    private javax.swing.JButton a2;
    private javax.swing.JButton a3;
    private javax.swing.JButton a4;
    private javax.swing.JButton a5;
    private javax.swing.JButton a6;
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JButton b4;
    private javax.swing.JButton b5;
    private javax.swing.JButton b6;
    private javax.swing.JButton c1;
    private javax.swing.JButton c2;
    private javax.swing.JButton c3;
    private javax.swing.JButton c4;
    private javax.swing.JButton c5;
    private javax.swing.JButton c6;
    private javax.swing.JButton d1;
    private javax.swing.JButton d2;
    private javax.swing.JButton d3;
    private javax.swing.JButton d4;
    private javax.swing.JButton d5;
    private javax.swing.JButton d6;
    private javax.swing.JButton e1;
    private javax.swing.JButton e2;
    private javax.swing.JButton e3;
    private javax.swing.JButton e4;
    private javax.swing.JButton e5;
    private javax.swing.JButton e6;
    private javax.swing.JButton f1;
    private javax.swing.JButton f2;
    private javax.swing.JButton f3;
    private javax.swing.JButton f4;
    private javax.swing.JButton f5;
    private javax.swing.JButton f6;
    // End of variables declaration//GEN-END:variables
}
