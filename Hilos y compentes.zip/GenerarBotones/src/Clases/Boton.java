package Clases;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class Boton extends JButton implements ActionListener {

    public Boton(int posx, int posy, int ancho, int alto) {
        setBounds(posx, posy, ancho, alto);
        addActionListener(this);
    }

    Boton() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void CambiarNombre(int f, int c) {
        //setText((x+1)+"-"+(y+1));
         setText( f + " , " + c );
          setBackground(Color.RED);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        setBackground(Color.white);
        setText("B");
       
    }

}
