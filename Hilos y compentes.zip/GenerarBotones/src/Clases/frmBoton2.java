package Clases;

import java.awt.Color;

public class frmBoton2 extends javax.swing.JFrame {

    public frmBoton2() {
        initComponents();
        valoresIniciales();
    }

    public void valoresIniciales() {
        btnA.setBackground(Color.red);
        btnA.setForeground(Color.gray);
        btnB.setBackground(Color.red);
        btnB.setForeground(Color.gray);
        btnC.setBackground(Color.red);
        btnC.setForeground(Color.gray);
        btnD.setBackground(Color.red);
        btnD.setForeground(Color.gray);
        btnE.setBackground(Color.red);
        btnE.setForeground(Color.gray);
        btnF.setBackground(Color.red);
        btnF.setForeground(Color.gray);
        btnG.setBackground(Color.red);
        btnG.setForeground(Color.gray);
        btnH.setBackground(Color.red);
        btnH.setForeground(Color.gray);
        btnI.setBackground(Color.red);
        btnI.setForeground(Color.gray);
        btnJ.setBackground(Color.red);
        btnJ.setForeground(Color.gray);
        btnK.setBackground(Color.red);
        btnK.setForeground(Color.gray);
        btnL.setBackground(Color.red);
        btnL.setForeground(Color.gray);
        btnM.setBackground(Color.red);
        btnM.setForeground(Color.gray);
        btnN.setBackground(Color.red);
        btnN.setForeground(Color.gray);
        btnO.setBackground(Color.red);
        btnO.setForeground(Color.gray);
        btnP.setBackground(Color.red);
        btnP.setForeground(Color.gray);
        btnQ.setBackground(Color.red);
        btnQ.setForeground(Color.gray);
        btnR.setBackground(Color.red);
        btnR.setForeground(Color.gray);
        btnS.setBackground(Color.red);
        btnS.setForeground(Color.gray);
        btnT.setBackground(Color.red);
        btnT.setForeground(Color.gray);
        btnU.setBackground(Color.red);
        btnU.setForeground(Color.gray);
        btnV.setBackground(Color.red);
        btnV.setForeground(Color.gray);
        btnW.setBackground(Color.red);
        btnW.setForeground(Color.gray);
        btnX.setBackground(Color.red);
        btnX.setForeground(Color.gray);

    }

    public void cambiarEstado() {

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnA = new javax.swing.JButton();
        btnB = new javax.swing.JButton();
        btnD = new javax.swing.JButton();
        btnC = new javax.swing.JButton();
        btnE = new javax.swing.JButton();
        btnF = new javax.swing.JButton();
        btnG = new javax.swing.JButton();
        btnH = new javax.swing.JButton();
        btnI = new javax.swing.JButton();
        btnJ = new javax.swing.JButton();
        btnK = new javax.swing.JButton();
        btnL = new javax.swing.JButton();
        btnM = new javax.swing.JButton();
        btnP = new javax.swing.JButton();
        btnQ = new javax.swing.JButton();
        btnN = new javax.swing.JButton();
        btnR = new javax.swing.JButton();
        btnO = new javax.swing.JButton();
        btnS = new javax.swing.JButton();
        btnV = new javax.swing.JButton();
        btnW = new javax.swing.JButton();
        btnT = new javax.swing.JButton();
        btnX = new javax.swing.JButton();
        btnU = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnA.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnA.setText("A");
        btnA.setPreferredSize(new java.awt.Dimension(100, 100));
        btnA.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnAFocusLost(evt);
            }
        });
        btnA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAActionPerformed(evt);
            }
        });

        btnB.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnB.setText("B");
        btnB.setPreferredSize(new java.awt.Dimension(100, 100));
        btnB.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnBFocusLost(evt);
            }
        });
        btnB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBActionPerformed(evt);
            }
        });

        btnD.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnD.setText("D");
        btnD.setPreferredSize(new java.awt.Dimension(100, 100));
        btnD.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnDFocusLost(evt);
            }
        });
        btnD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDActionPerformed(evt);
            }
        });

        btnC.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnC.setText("C");
        btnC.setPreferredSize(new java.awt.Dimension(100, 100));
        btnC.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnCFocusLost(evt);
            }
        });
        btnC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCActionPerformed(evt);
            }
        });

        btnE.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnE.setText("E");
        btnE.setPreferredSize(new java.awt.Dimension(100, 100));
        btnE.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnEFocusLost(evt);
            }
        });
        btnE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEActionPerformed(evt);
            }
        });

        btnF.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnF.setText("F");
        btnF.setPreferredSize(new java.awt.Dimension(100, 100));
        btnF.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnFFocusLost(evt);
            }
        });
        btnF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFActionPerformed(evt);
            }
        });

        btnG.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnG.setText("G");
        btnG.setPreferredSize(new java.awt.Dimension(100, 100));
        btnG.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnGFocusLost(evt);
            }
        });
        btnG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGActionPerformed(evt);
            }
        });

        btnH.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnH.setText("H");
        btnH.setPreferredSize(new java.awt.Dimension(100, 100));
        btnH.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnHFocusLost(evt);
            }
        });
        btnH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHActionPerformed(evt);
            }
        });

        btnI.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnI.setText("I");
        btnI.setPreferredSize(new java.awt.Dimension(100, 100));
        btnI.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnIFocusLost(evt);
            }
        });
        btnI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIActionPerformed(evt);
            }
        });

        btnJ.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnJ.setText("J");
        btnJ.setPreferredSize(new java.awt.Dimension(100, 100));
        btnJ.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnJFocusLost(evt);
            }
        });
        btnJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJActionPerformed(evt);
            }
        });

        btnK.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnK.setText("K");
        btnK.setPreferredSize(new java.awt.Dimension(100, 100));
        btnK.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnKFocusLost(evt);
            }
        });
        btnK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKActionPerformed(evt);
            }
        });

        btnL.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnL.setText("L");
        btnL.setPreferredSize(new java.awt.Dimension(100, 100));
        btnL.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnLFocusLost(evt);
            }
        });
        btnL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLActionPerformed(evt);
            }
        });

        btnM.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnM.setText("M");
        btnM.setPreferredSize(new java.awt.Dimension(100, 100));
        btnM.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnMFocusLost(evt);
            }
        });
        btnM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMActionPerformed(evt);
            }
        });

        btnP.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnP.setText("P");
        btnP.setPreferredSize(new java.awt.Dimension(100, 100));
        btnP.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnPFocusLost(evt);
            }
        });
        btnP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPActionPerformed(evt);
            }
        });

        btnQ.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnQ.setText("Q");
        btnQ.setPreferredSize(new java.awt.Dimension(100, 100));
        btnQ.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnQFocusLost(evt);
            }
        });
        btnQ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQActionPerformed(evt);
            }
        });

        btnN.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnN.setText("N");
        btnN.setPreferredSize(new java.awt.Dimension(100, 100));
        btnN.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnNFocusLost(evt);
            }
        });
        btnN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNActionPerformed(evt);
            }
        });

        btnR.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnR.setText("R");
        btnR.setPreferredSize(new java.awt.Dimension(100, 100));
        btnR.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnRFocusLost(evt);
            }
        });
        btnR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRActionPerformed(evt);
            }
        });

        btnO.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnO.setText("O");
        btnO.setPreferredSize(new java.awt.Dimension(100, 100));
        btnO.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnOFocusLost(evt);
            }
        });
        btnO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOActionPerformed(evt);
            }
        });

        btnS.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnS.setText("S");
        btnS.setPreferredSize(new java.awt.Dimension(100, 100));
        btnS.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnSFocusLost(evt);
            }
        });
        btnS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSActionPerformed(evt);
            }
        });

        btnV.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnV.setText("V");
        btnV.setPreferredSize(new java.awt.Dimension(100, 100));
        btnV.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnVFocusLost(evt);
            }
        });
        btnV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVActionPerformed(evt);
            }
        });

        btnW.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnW.setText("W");
        btnW.setPreferredSize(new java.awt.Dimension(100, 100));
        btnW.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnWFocusLost(evt);
            }
        });
        btnW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWActionPerformed(evt);
            }
        });

        btnT.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnT.setText("T");
        btnT.setPreferredSize(new java.awt.Dimension(100, 100));
        btnT.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnTFocusLost(evt);
            }
        });
        btnT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTActionPerformed(evt);
            }
        });

        btnX.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnX.setText("X");
        btnX.setPreferredSize(new java.awt.Dimension(100, 100));
        btnX.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnXFocusLost(evt);
            }
        });
        btnX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXActionPerformed(evt);
            }
        });

        btnU.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        btnU.setText("U");
        btnU.setPreferredSize(new java.awt.Dimension(100, 100));
        btnU.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                btnUFocusLost(evt);
            }
        });
        btnU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnQ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnW, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnX, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnQ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnW, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnX, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAActionPerformed

        btnA.setBackground(Color.white);
        btnA.setText("a");
    }//GEN-LAST:event_btnAActionPerformed

    private void btnBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBActionPerformed
        btnB.setBackground(Color.white);
        btnB.setText("b");
    }//GEN-LAST:event_btnBActionPerformed

    private void btnAFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnAFocusLost
        btnA.setBackground(Color.red);
        btnA.setForeground(Color.black);
        btnA.setText("A");
    }//GEN-LAST:event_btnAFocusLost

    private void btnBFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnBFocusLost
        btnB.setBackground(Color.red);
        btnB.setForeground(Color.black);
        btnB.setText("B");
    }//GEN-LAST:event_btnBFocusLost

    private void btnDFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnDFocusLost
        btnD.setBackground(Color.red);
        btnD.setForeground(Color.black);
        btnD.setText("D");
    }//GEN-LAST:event_btnDFocusLost

    private void btnDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDActionPerformed
        btnD.setBackground(Color.white);
        btnD.setText("d");
    }//GEN-LAST:event_btnDActionPerformed

    private void btnCFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnCFocusLost
        btnC.setBackground(Color.red);
        btnC.setForeground(Color.black);
        btnC.setText("C");
    }//GEN-LAST:event_btnCFocusLost

    private void btnCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCActionPerformed
        btnC.setBackground(Color.white);
        btnC.setText("c");
    }//GEN-LAST:event_btnCActionPerformed

    private void btnEFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnEFocusLost
        btnE.setBackground(Color.red);
        btnE.setForeground(Color.black);
        btnE.setText("E");
    }//GEN-LAST:event_btnEFocusLost

    private void btnEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEActionPerformed
        btnE.setBackground(Color.white);
        btnE.setText("e");
    }//GEN-LAST:event_btnEActionPerformed

    private void btnFFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnFFocusLost
        btnF.setBackground(Color.red);
        btnF.setForeground(Color.black);
        btnF.setText("F");
    }//GEN-LAST:event_btnFFocusLost

    private void btnFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFActionPerformed
        btnF.setBackground(Color.white);
        btnF.setText("f");
    }//GEN-LAST:event_btnFActionPerformed

    private void btnGFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnGFocusLost
        btnG.setBackground(Color.red);
        btnG.setForeground(Color.black);
        btnG.setText("G");
    }//GEN-LAST:event_btnGFocusLost

    private void btnGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGActionPerformed
        btnG.setBackground(Color.white);
        btnG.setText("g");
    }//GEN-LAST:event_btnGActionPerformed

    private void btnHFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnHFocusLost
         btnH.setBackground(Color.red);
        btnH.setForeground(Color.black);
        btnH.setText("H");
    }//GEN-LAST:event_btnHFocusLost

    private void btnHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHActionPerformed
       btnH.setBackground(Color.white);
        btnH.setText("h");
    }//GEN-LAST:event_btnHActionPerformed

    private void btnIFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnIFocusLost
       btnI.setBackground(Color.red);
        btnI.setForeground(Color.black);
        btnI.setText("I");
    }//GEN-LAST:event_btnIFocusLost

    private void btnIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIActionPerformed
         btnI.setBackground(Color.white);
        btnI.setText("i");
    }//GEN-LAST:event_btnIActionPerformed

    private void btnJFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnJFocusLost
         btnJ.setBackground(Color.red);
        btnJ.setForeground(Color.black);
        btnJ.setText("J");
    }//GEN-LAST:event_btnJFocusLost

    private void btnJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJActionPerformed
         btnJ.setBackground(Color.white);
        btnJ.setText("j");
    }//GEN-LAST:event_btnJActionPerformed

    private void btnKFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnKFocusLost
         btnK.setBackground(Color.red);
        btnK.setForeground(Color.black);
        btnK.setText("K");
    }//GEN-LAST:event_btnKFocusLost

    private void btnKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKActionPerformed
         btnK.setBackground(Color.white);
        btnK.setText("k");
    }//GEN-LAST:event_btnKActionPerformed

    private void btnLFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnLFocusLost
        btnL.setBackground(Color.red);
        btnL.setForeground(Color.black);
        btnL.setText("L");
    }//GEN-LAST:event_btnLFocusLost

    private void btnLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLActionPerformed
        btnL.setBackground(Color.white);
        btnL.setText("l");
    }//GEN-LAST:event_btnLActionPerformed

    private void btnMFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnMFocusLost
        btnM.setBackground(Color.red);
        btnM.setForeground(Color.black);
        btnM.setText("M");
    }//GEN-LAST:event_btnMFocusLost

    private void btnMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMActionPerformed
       btnM.setBackground(Color.white);
        btnM.setText("m");
    }//GEN-LAST:event_btnMActionPerformed

    private void btnPFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnPFocusLost
       btnP.setBackground(Color.red);
        btnP.setForeground(Color.black);
        btnP.setText("p");
    }//GEN-LAST:event_btnPFocusLost

    private void btnPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPActionPerformed
        btnP.setBackground(Color.white);
        btnP.setText("p");
    }//GEN-LAST:event_btnPActionPerformed

    private void btnQFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnQFocusLost
        btnQ.setBackground(Color.red);
        btnQ.setForeground(Color.black);
        btnQ.setText("Q");
    }//GEN-LAST:event_btnQFocusLost

    private void btnQActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQActionPerformed
         btnQ.setBackground(Color.white);
        btnQ.setText("q");
    }//GEN-LAST:event_btnQActionPerformed

    private void btnNFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnNFocusLost
         btnN.setBackground(Color.red);
        btnN.setForeground(Color.black);
        btnN.setText("N");
    }//GEN-LAST:event_btnNFocusLost

    private void btnNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNActionPerformed
         btnN.setBackground(Color.white);
        btnN.setText("n");
    }//GEN-LAST:event_btnNActionPerformed

    private void btnRFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnRFocusLost
        btnR.setBackground(Color.red);
        btnR.setForeground(Color.black);
        btnR.setText("R");
    }//GEN-LAST:event_btnRFocusLost

    private void btnRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRActionPerformed
         btnR.setBackground(Color.white);
        btnR.setText("r");
    }//GEN-LAST:event_btnRActionPerformed

    private void btnOFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnOFocusLost
        btnO.setBackground(Color.red);
        btnO.setForeground(Color.black);
        btnO.setText("O");
    }//GEN-LAST:event_btnOFocusLost

    private void btnOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOActionPerformed
       btnO.setBackground(Color.white);
        btnO.setText("o");
    }//GEN-LAST:event_btnOActionPerformed

    private void btnSFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnSFocusLost
        btnS.setBackground(Color.red);
        btnS.setForeground(Color.black);
        btnS.setText("S");
    }//GEN-LAST:event_btnSFocusLost

    private void btnSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSActionPerformed
        btnS.setBackground(Color.white);
        btnS.setText("s");
    }//GEN-LAST:event_btnSActionPerformed

    private void btnVFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnVFocusLost
        btnV.setBackground(Color.red);
        btnV.setForeground(Color.black);
        btnV.setText("V");
    }//GEN-LAST:event_btnVFocusLost

    private void btnVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVActionPerformed
         btnV.setBackground(Color.white);
        btnV.setText("v");
    }//GEN-LAST:event_btnVActionPerformed

    private void btnWFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnWFocusLost
       btnW.setBackground(Color.red);
        btnW.setForeground(Color.black);
        btnW.setText("W");
    }//GEN-LAST:event_btnWFocusLost

    private void btnWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWActionPerformed
     btnW.setBackground(Color.white);
        btnW.setText("w");
    }//GEN-LAST:event_btnWActionPerformed

    private void btnTFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnTFocusLost
        btnT.setBackground(Color.red);
        btnT.setForeground(Color.black);
        btnT.setText("T");
    }//GEN-LAST:event_btnTFocusLost

    private void btnTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTActionPerformed
         btnT.setBackground(Color.white);
        btnT.setText("t");
    }//GEN-LAST:event_btnTActionPerformed

    private void btnXFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnXFocusLost
        btnX.setBackground(Color.red);
        btnX.setForeground(Color.black);
        btnX.setText("X");
    }//GEN-LAST:event_btnXFocusLost

    private void btnXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXActionPerformed
        btnX.setBackground(Color.white);
        btnX.setText("x");
    }//GEN-LAST:event_btnXActionPerformed

    private void btnUFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_btnUFocusLost
        btnU.setBackground(Color.red);
        btnU.setForeground(Color.black);
        btnU.setText("U");
    }//GEN-LAST:event_btnUFocusLost

    private void btnUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUActionPerformed
        btnU.setBackground(Color.white);
        btnU.setText("u");
    }//GEN-LAST:event_btnUActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmBoton2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmBoton2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmBoton2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmBoton2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmBoton2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnA;
    private javax.swing.JButton btnB;
    private javax.swing.JButton btnC;
    private javax.swing.JButton btnD;
    private javax.swing.JButton btnE;
    private javax.swing.JButton btnF;
    private javax.swing.JButton btnG;
    private javax.swing.JButton btnH;
    private javax.swing.JButton btnI;
    private javax.swing.JButton btnJ;
    private javax.swing.JButton btnK;
    private javax.swing.JButton btnL;
    private javax.swing.JButton btnM;
    private javax.swing.JButton btnN;
    private javax.swing.JButton btnO;
    private javax.swing.JButton btnP;
    private javax.swing.JButton btnQ;
    private javax.swing.JButton btnR;
    private javax.swing.JButton btnS;
    private javax.swing.JButton btnT;
    private javax.swing.JButton btnU;
    private javax.swing.JButton btnV;
    private javax.swing.JButton btnW;
    private javax.swing.JButton btnX;
    // End of variables declaration//GEN-END:variables
}
